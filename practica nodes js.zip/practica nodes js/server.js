const express = require('express');
const app = express();

app.get('/', (req, res) => {
  res.json({
    nombre: 'Elias Hernandez',
    conocimientosYHabilidades: {
      areasTecnicas: ['Procesamiento del lenguaje natural', 'Aprendizaje automático', 'Inteligencia artificial'],
      hobbies: ['Leer', 'Cocinar', 'Viajar']
    }
  });
});

app.listen(3000, () => {
  console.log('Servidor escuchando en el puerto 3000');
});
